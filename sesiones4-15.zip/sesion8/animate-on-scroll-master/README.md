# Animate on Scroll
Javascript library to effect content when scroll page. No require jQuery. Use animate.css

## Todo

- Create documentation;
- Make test;
- Check browsers compatibility;
- Add to free CDN's;

# LICENSE

MIT license
